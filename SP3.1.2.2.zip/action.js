$(".player").empty();
$("#sp3").css("display", "none");
$($( "#see-inside" ).parent()).attr('href','https://llk.github.io/scratch-gui/#' + location.href.slice(33));
$('.player').append('<div id="player" style="width:500px;height:410px;overflow:hidden;position:relative;left:-8px;top:10px;"><object style="position:absolute;top:-51px;left:-2060px" class="int-player" width="2560" height="1440" data="https://llk.github.io/scratch-gui/#' + location.href.slice(33) + '" scrolling="no"></object></div>');
$(".stage").css("background", "#e8edf1");