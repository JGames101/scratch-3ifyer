var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        var myObj = JSON.parse(this.responseText);
        if (myObj.version > 1.2.1) {
			var newURL = "https://jgames101.github.io/scratch-player-3/update.html";
			chrome.tabs.create({ url: newURL });	
		}
    }
};
if(location.href.startsWith("https://scratch.mit.edu/accounts/settings/")) {
	chrome.tabs.executeScript(tab.id, {
		file: 'jquery-3.2.1.min.js'
	});
	chrome.tabs.executeScript(tab.id, {
		file: 'settings.js'
	});
}

xmlhttp.open("GET", "https://jgames101.github.io/scratch-player-3/latest.json", true);
xmlhttp.send();
chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.tabs.executeScript(tab.id, {
		file: 'jquery-3.2.1.min.js'
	});
	chrome.tabs.executeScript(tab.id, {
		file: 'action.js'
	});
});